# from flask import Flask, request, jsonify
# from mongodb_connector import get_mongo_client
# from bson.objectid import ObjectId
# from datetime import datetime

# app = Flask(__name__)
# db = get_mongo_client()  # Get the MongoDB database connection

# @app.route('/data', methods=['POST'])
# def create_data():
#     """Create a new data entry."""
#     data = request.json  # Get JSON data from the request
#     if not data:
#         return jsonify({"error": "No data provided"}), 400
    
#     result = db.sensor_readings.insert_one(data)
#     if result.acknowledged:
#         return jsonify({"message": f"Data inserted with ID: {result.inserted_id}"}), 201
#     else:
#         return jsonify({"error": "Data insertion failed"}), 500

# @app.route('/data', methods=['GET'])
# def read_data():
#     """Read all data entries."""
#     data = list(db.sensor_readings.find())
#     for entry in data:
#         entry['_id'] = str(entry['_id'])  # Convert ObjectId to string for JSON serialization
#     return jsonify(data), 200

# @app.route('/data/<data_id>', methods=['GET'])
# def read_data_by_id(data_id):
#     """Read a single data entry by ID."""
#     try:
#         data = db.sensor_readings.find_one({"_id": ObjectId(data_id)})
#         if data:
#             data['_id'] = str(data['_id'])  # Convert ObjectId to string for JSON serialization
#             return jsonify(data), 200
#         else:
#             return jsonify({"error": "Data not found"}), 404
#     except Exception as e:
#         return jsonify({"error": str(e)}), 400

# @app.route('/data/range', methods=['GET'])
# def read_data_in_range():
#     """Read data entries within a specific timestamp range."""
#     from_timestamp = request.args.get('from')
#     to_timestamp = request.args.get('to')

#     if not from_timestamp or not to_timestamp:
#         return jsonify({"error": "Please provide 'from' and 'to' timestamps"}), 400

#     print(f"Received 'from' timestamp: {from_timestamp}")
#     print(f"Received 'to' timestamp: {to_timestamp}")

#     try:
#         # Convert the 'from' and 'to' timestamps from string to datetime
#         from_datetime = datetime.strptime(from_timestamp, '%Y-%m-%d %H:%M:%S')
#         to_datetime = datetime.strptime(to_timestamp, '%Y-%m-%d %H:%M:%S')

#         print(f"Converted 'from' datetime: {from_datetime}")
#         print(f"Converted 'to' datetime: {to_datetime}")

#         # Query MongoDB for entries within the timestamp range
#         data = list(db.sensor_readings.find({
#             "timestamp": {
#                 "$gte": from_timestamp,
#                 "$lte": to_timestamp
#             }
#         }))

#         for entry in data:
#             entry['_id'] = str(entry['_id'])  # Convert ObjectId to string for JSON serialization

#         return jsonify(data), 200
#     except ValueError:
#         return jsonify({"error": "Invalid timestamp format. Please use 'YYYY-MM-DD HH:MM:SS'."}), 400

# @app.route('/data/<data_id>', methods=['PUT'])
# def update_data(data_id):
#     """Update a data entry by ID."""
#     update_data = request.json  # Get JSON data from the request
#     if not update_data:
#         return jsonify({"error": "No data provided"}), 400
    
#     try:
#         result = db.sensor_readings.update_one({"_id": ObjectId(data_id)}, {"$set": update_data})
#         if result.matched_count:
#             return jsonify({"message": "Data updated successfully"}), 200
#         else:
#             return jsonify({"error": "Data not found or update failed"}), 404
#     except Exception as e:
#         return jsonify({"error": str(e)}), 400

# @app.route('/data/<data_id>', methods=['DELETE'])
# def delete_data(data_id):
#     """Delete a data entry by ID."""
#     try:
#         result = db.sensor_readings.delete_one({"_id": ObjectId(data_id)})
#         if result.deleted_count:
#             return jsonify({"message": "Data deleted successfully"}), 200
#         else:
#             return jsonify({"error": "Data not found or delete failed"}), 404
#     except Exception as e:
#         return jsonify({"error": str(e)}), 400

# if __name__ == '__main__':
#     app.run(debug=True)





from flask import Flask, request, jsonify, render_template
from mongodb_connector import get_mongo_client
from bson.objectid import ObjectId
from datetime import datetime
import os

app = Flask(__name__)
# Use the MONGO_URI from environment variables
mongo_uri = os.getenv('MONGO_URI', 'mongodb://localhost:27017/sensor_data')
db = get_mongo_client(mongo_uri)  # Pass the URI to the connection function

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/create', methods=['GET'])
def create():
    return render_template('create.html')

@app.route('/read', methods=['GET'])
def read():
    return render_template('read.html')

@app.route('/read_by_id', methods=['GET'])
def read_by_id():
    return render_template('read_by_id.html')

@app.route('/read_by_range', methods=['GET'])
def read_by_range():
    return render_template('read_by_range.html')

@app.route('/update', methods=['GET'])
def update():
    return render_template('update.html')

@app.route('/delete', methods=['GET'])
def delete():
    return render_template('delete.html')

@app.route('/data', methods=['POST'])
def create_data():
    """Create a new data entry."""
    data = request.json  # Get JSON data from the request
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    result = db.sensor_readings.insert_one(data)
    if result.acknowledged:
        return jsonify({"message": f"Data inserted with ID: {result.inserted_id}"}), 201
    else:
        return jsonify({"error": "Data insertion failed"}), 500

@app.route('/data', methods=['GET'])
def read_data():
    """Read all data entries."""
    data = list(db.sensor_readings.find())
    for entry in data:
        entry['_id'] = str(entry['_id'])  # Convert ObjectId to string for JSON serialization
    return jsonify(data), 200

@app.route('/data/<data_id>', methods=['GET'])
def read_data_by_id(data_id):
    """Read a single data entry by ID."""
    try:
        data = db.sensor_readings.find_one({"_id": ObjectId(data_id)})
        if data:
            data['_id'] = str(data['_id'])  # Convert ObjectId to string for JSON serialization
            return jsonify(data), 200
        else:
            return jsonify({"error": "Data not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/data/range', methods=['GET'])
def read_data_in_range():
    """Read data entries within a specific timestamp range."""
    from_timestamp = request.args.get('from')
    to_timestamp = request.args.get('to')

    if not from_timestamp or not to_timestamp:
        return jsonify({"error": "Please provide 'from' and 'to' timestamps"}), 400

    try:
        # Ensure the timestamps are in the correct string format
        data = list(db.sensor_readings.find({
            "timestamp": {
                "$gte": from_timestamp,
                "$lte": to_timestamp
            }
        }))

        for entry in data:
            entry['_id'] = str(entry['_id'])  # Convert ObjectId to string for JSON serialization

        if not data:
            return jsonify({"message": "No data found in the specified range"}), 404

        return jsonify(data), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400



@app.route('/data/<data_id>', methods=['PUT'])
def update_data(data_id):
    """Update a data entry by ID."""
    update_data = request.json  # Get JSON data from the request
    if not update_data:
        return jsonify({"error": "No data provided"}), 400
    
    try:
        result = db.sensor_readings.update_one({"_id": ObjectId(data_id)}, {"$set": update_data})
        if result.matched_count:
            return jsonify({"message": "Data updated successfully"}), 200
        else:
            return jsonify({"error": "Data not found or update failed"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/data/<data_id>', methods=['DELETE'])
def delete_data(data_id):
    """Delete a data entry by ID."""
    try:
        result = db.sensor_readings.delete_one({"_id": ObjectId(data_id)})
        if result.deleted_count:
            return jsonify({"message": "Data deleted successfully"}), 200
        else:
            return jsonify({"error": "Data not found or delete failed"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)