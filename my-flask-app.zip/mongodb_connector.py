from pymongo import MongoClient

def get_mongo_client(uri='mongodb://localhost:27017/', db_name='sensor_data'):
    client = MongoClient(uri)
    db = client[db_name]
    return db

def insert_data(collection_name, data):
    db = get_mongo_client()
    collection = db[collection_name]
    result = collection.insert_one(data)
    if result.acknowledged:
        print(f"Data inserted with ID: {result.inserted_id}")
    else:
        print("Data insertion failed.")
