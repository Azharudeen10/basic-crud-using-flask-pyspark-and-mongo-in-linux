import time
import random
from datetime import datetime

def generate_data():
    while True:
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        temperature = round(random.uniform(15.0, 30.0), 2)
        humidity = round(random.uniform(30.0, 60.0), 2)
        yield {"timestamp": timestamp, "temperature": temperature, "humidity": humidity}
        time.sleep(5)

if __name__ == "__main__":
    for data in generate_data():
        print(f"Generated Data: {data}")
