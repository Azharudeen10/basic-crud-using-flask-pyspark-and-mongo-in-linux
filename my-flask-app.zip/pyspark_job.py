from pyspark.sql import SparkSession
from mongodb_connector import insert_data
from data_generation import generate_data

def main():
    # Initialize Spark session
    spark = SparkSession.builder \
        .appName("TemperatureHumidityJob") \
        .getOrCreate()
    print("Spark session created successfully.")

    # Define schema
    schema = "timestamp STRING, temperature DOUBLE, humidity DOUBLE"

    try:
        # Generate and process data
        for data in generate_data():
            df = spark.createDataFrame([data], schema=schema)
            print(f"DataFrame created: {data}")

            # Save to MongoDB
            insert_data('sensor_readings', data)
            print(f"Data saved to MongoDB: {data}")

    except KeyboardInterrupt:
        print("Process interrupted by user. Exiting gracefully...")
    finally:
        # Stop the Spark session
        spark.stop()
        print("Spark session stopped.")

if __name__ == "__main__":
    main()
